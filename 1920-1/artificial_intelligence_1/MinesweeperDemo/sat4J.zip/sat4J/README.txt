soubor "problem.txt" obsahuje zadani problemu (formuli v CNF). Format je presne popsany v souboru "format.pdf".

Resic spustite pomoci souboru "solver.bat" z prikazove radky, nebo alternativne pomoci prikazu
java -jar org.sat4j.core.jar problem.txt

Vysledky budou vypsane na prikazovou radku. Radky zacinajici symbolem "c" predstavuji komentar.